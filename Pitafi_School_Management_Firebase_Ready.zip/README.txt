PITAFISOFT SCHOOL MANAGEMENT — FIREBASE-READY STARTER
====================================================

Start with FIREBASE_SETUP_SINDHI.txt. It explains Firebase setup in Sindhi, including the required Admin membership record.

The ZIP cannot create a Firebase project inside your Google account automatically. You must create the project and copy its Web App config into js/firebase.js. No Google password or private credentials should be shared in chat.

This is a starter project, not a finished production school platform. Current cloud sync is primarily an upload queue; bidirectional multi-device sync/conflict resolution, teacher/parent roles, photos and PDF report cards are not yet implemented. Test with fake data only until these are completed and security is reviewed.

Preview:
- Use HTTPS hosting or a local development web server.
- Do not open index.html directly as file://.
- Open local demo to test the UI; demo mode is local-only and does not sync to Firebase.
