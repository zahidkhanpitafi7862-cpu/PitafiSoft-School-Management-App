const DB_NAME = "school-management-offline";
const DB_VERSION = 1;
const STORES = ["students","teachers","classes","attendance","exams","fees","notices","syncQueue","meta"];

function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      for (const name of STORES) {
        if (!db.objectStoreNames.contains(name)) {
          const store = db.createObjectStore(name, { keyPath: "id" });
          if (name === "students") store.createIndex("name", "name", { unique: false });
          if (name === "attendance") store.createIndex("date", "date", { unique: false });
        }
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Could not open local database"));
  });
}
const dbPromise = openDb();

export async function getAll(storeName) {
  const db = await dbPromise;
  return new Promise((resolve, reject) => {
    const req = db.transaction(storeName, "readonly").objectStore(storeName).getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}
export async function getOne(storeName, id) {
  const db = await dbPromise;
  return new Promise((resolve, reject) => {
    const req = db.transaction(storeName, "readonly").objectStore(storeName).get(id);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
}
export async function put(storeName, value) {
  const db = await dbPromise;
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readwrite");
    tx.objectStore(storeName).put(value);
    tx.oncomplete = () => resolve(value);
    tx.onerror = () => reject(tx.error || new Error("Save failed"));
    tx.onabort = () => reject(tx.error || new Error("Save cancelled"));
  });
}
export async function remove(storeName, id) {
  const db = await dbPromise;
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readwrite");
    tx.objectStore(storeName).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
export async function clearStore(storeName) {
  const db = await dbPromise;
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readwrite");
    tx.objectStore(storeName).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
export async function enqueue(item) {
  return put("syncQueue", item);
}
export async function queueCount() {
  return (await getAll("syncQueue")).length;
}
export async function getMeta(key) {
  return getOne("meta", key);
}
export async function setMeta(key, value) {
  return put("meta", { id: key, value });
}
export async function exportAll() {
  const result = {};
  for (const name of STORES) result[name] = await getAll(name);
  return { app: "School Management System", formatVersion: 1, exportedAt: new Date().toISOString(), stores: result };
}
export async function importAll(data) {
  if (!data || !data.stores || typeof data.stores !== "object") throw new Error("Invalid backup file");
  for (const name of STORES) {
    if (!Array.isArray(data.stores[name])) continue;
    await clearStore(name);
    for (const row of data.stores[name]) await put(name, row);
  }
}
