// Paste your Firebase web-app configuration here.
// Create a project at https://console.firebase.google.com/
// Enable Authentication (Email/Password), Cloud Firestore, and Storage if you need photos.
export const firebaseConfig = {
  apiKey: "PASTE_API_KEY_HERE",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};

export const firebaseConfigured = Boolean(
  firebaseConfig.apiKey &&
  firebaseConfig.apiKey !== "PASTE_API_KEY_HERE" &&
  firebaseConfig.projectId &&
  firebaseConfig.projectId !== "PASTE_PROJECT_ID"
);
