import { getAll, getOne, put, remove, exportAll, importAll, queueCount, getMeta, setMeta } from "./database.js";
import { initializeFirebase, isFirebaseConfigured, signIn, signOut, setDemoMode, isDemoMode, currentUser, syncPending } from "./sync.js";

const $ = (id) => document.getElementById(id);
const root = $("viewRoot");
let currentView = "dashboard";
let currentCollection = null;
let currentEditId = null;
let toastTimer = null;
const titles = {dashboard:"Dashboard",students:"Students",teachers:"Teachers",classes:"Classes",attendance:"Attendance",exams:"Examinations",fees:"Fees",notices:"Notices",settings:"Settings & Backup"};
const schema = {
  students: [
    ["name","Full name","text",true],["rollNo","Roll number","text",true],["className","Class / section","text",true],["gender","Gender","select",true,["Male","Female","Other"]],["guardian","Parent / guardian","text",false],["phone","Contact number","tel",false],["dateOfBirth","Date of birth","date",false],["address","Address","textarea",false],["status","Status","select",true,["Active","Inactive"]]
  ],
  teachers: [
    ["name","Full name","text",true],["employeeId","Employee ID","text",true],["subject","Subject","text",false],["phone","Contact number","tel",false],["email","Email","email",false],["status","Status","select",true,["Active","Inactive"]]
  ],
  classes: [
    ["name","Class name","text",true],["section","Section","text",false],["teacher","Class teacher","text",false],["room","Room","text",false],["academicYear","Academic year","text",false]
  ],
  attendance: [
    ["date","Date","date",true],["className","Class / section","text",true],["studentName","Student name","text",true],["rollNo","Roll number","text",false],["status","Attendance","select",true,["Present","Absent","Late","Leave"]],["remarks","Remarks","text",false]
  ],
  exams: [
    ["studentName","Student name","text",true],["rollNo","Roll number","text",false],["className","Class / section","text",true],["examName","Exam name","text",true],["subject","Subject","text",true],["totalMarks","Total marks","number",true],["obtainedMarks","Obtained marks","number",true],["remarks","Remarks","text",false]
  ],
  fees: [
    ["studentName","Student name","text",true],["rollNo","Roll number","text",false],["className","Class / section","text",false],["month","Fee month","month",true],["amountDue","Amount due (PKR)","number",true],["amountPaid","Amount paid (PKR)","number",true],["paidOn","Paid on","date",false],["remarks","Remarks","text",false]
  ],
  notices: [
    ["title","Notice title","text",true],["audience","Audience","select",true,["All","Teachers","Students","Parents"]],["body","Message","textarea",true],["publishDate","Publish date","date",true]
  ]
};
const collectionLabels = {students:"Students",teachers:"Teachers",classes:"Classes",attendance:"Attendance",exams:"Examinations",fees:"Fees",notices:"Notices"};

function escapeHtml(value="") {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function money(value) { return "PKR " + Number(value || 0).toLocaleString("en-PK"); }
function today() { return new Date().toISOString().slice(0,10); }
function toast(message, error=false) {
  const el=$("toast"); el.textContent=message; el.classList.remove("hidden","error"); if(error)el.classList.add("error");
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.add("hidden"),4200);
}
function uid() { return crypto.randomUUID ? crypto.randomUUID() : "id-"+Date.now()+"-"+Math.random().toString(16).slice(2); }
function initials(name="") { return name.trim().split(/\s+/).slice(0,2).map(s=>s[0]||"").join("").toUpperCase() || "?"; }
function dateLabel() { $("todayLabel").textContent = new Date().toLocaleDateString(undefined,{weekday:"long",year:"numeric",month:"long",day:"numeric"}); }
function updateConnection() {
  const online=navigator.onLine; $("connectionBadge").textContent=online?"● Online":"● Offline";
  $("connectionBadge").className="status-pill "+(online?"online":"offline");
}
async function updateSyncBadge() {
  const count=await queueCount();
  $("syncBadge").textContent = isDemoMode() ? "Sync: demo only" : count ? `Sync: ${count} pending` : "Sync: up to date";
  $("syncBadge").className="status-pill "+(count?"pending":"online");
}
function showApp() {
  $("loginScreen").classList.add("hidden"); $("appShell").classList.remove("hidden");
  $("roleBadge").textContent=isDemoMode()?"Local demo":"Signed in";
  dateLabel(); updateConnection(); renderView(); updateSyncBadge();
}
function showLogin() { $("appShell").classList.add("hidden"); $("loginScreen").classList.remove("hidden"); }
function navTo(view) {
  currentView=view; document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
  $("pageTitle").textContent=titles[view]||"Dashboard"; $("sidebar")?.classList.remove("open");
  document.querySelector(".sidebar").classList.remove("open"); renderView();
}
function pageHeading(title, subtitle, action="") {
  return `<div class="page-heading"><div><h3>${title}</h3><p>${subtitle}</p></div>${action}</div>`;
}
function statCard(label,value,icon,tint,foot="Updated from local records") {
  return `<article class="stat-card" style="--tint:${tint}"><div class="stat-top"><span>${label}</span><span class="stat-icon">${icon}</span></div><div class="stat-value">${value}</div><div class="stat-foot">${foot}</div></article>`;
}
function emptyState(title,body) { return `<div class="empty-state"><strong>${title}</strong>${body}</div>`; }

async function renderView() {
  try {
    if(currentView==="dashboard") return await renderDashboard();
    if(currentView==="settings") return await renderSettings();
    if(currentView==="notices") return await renderNotices();
    if(currentView==="attendance") return await renderAttendance();
    if(currentView==="fees") return await renderFees();
    if(currentView==="exams") return await renderExams();
    if(["students","teachers","classes"].includes(currentView)) return await renderCollection(currentView);
    root.innerHTML=emptyState("Coming soon","This module will be available in a later build.");
  } catch(e) { console.error(e); root.innerHTML=emptyState("Could not load this page",escapeHtml(e.message)); }
}
async function renderDashboard() {
  const [students,teachers,classes,attendance,fees,notices]=await Promise.all(["students","teachers","classes","attendance","fees","notices"].map(getAll));
  const todays=attendance.filter(r=>r.date===today());
  const present=todays.filter(r=>r.status==="Present"||r.status==="Late").length;
  const paid=fees.reduce((n,r)=>n+Number(r.amountPaid||0),0);
  const due=fees.reduce((n,r)=>n+Math.max(0,Number(r.amountDue||0)-Number(r.amountPaid||0)),0);
  root.innerHTML=`
    ${pageHeading("Good day!","Here is your school's current overview.",'<button class="primary" data-add="students">＋ Add student</button>')}
    <div class="grid stats-grid">
      ${statCard("Total students",students.length,"♙","#dcecff")}
      ${statCard("Total teachers",teachers.length,"♟","#f7dce9")}
      ${statCard("Present today",present,"✓","#d9f5e9",`${todays.length} attendance entries today`)}
      ${statCard("Fees collected",money(paid),"₨","#fff0d9",`${money(due)} outstanding in entered fee records`)}
    </div>
    <div class="grid dashboard-grid">
      <section class="panel"><h3>Quick actions</h3><div class="panel-sub">Common tasks for school administration</div>
        <div class="quick-grid">
          <button class="quick-action" data-add="students"><span>♙</span><b>Add student</b></button>
          <button class="quick-action" data-add="teachers"><span>♟</span><b>Add teacher</b></button>
          <button class="quick-action" data-add="attendance"><span>✓</span><b>Mark attendance</b></button>
          <button class="quick-action" data-add="exams"><span>✎</span><b>Enter result</b></button>
          <button class="quick-action" data-add="fees"><span>₨</span><b>Record fee</b></button>
          <button class="quick-action" data-view="notices"><span>🔔</span><b>Publish notice</b></button>
        </div>
      </section>
      <section class="panel"><h3>Offline & sync status</h3><div class="panel-sub">Your records are stored on this device first</div>
        <div class="sync-info"><b>${navigator.onLine?"Internet connection detected":"Currently offline"}</b><br>Pending records: <b id="dashPending">…</b><br>Last successful sync: <b id="lastSyncText">Never</b><br><span class="small-muted">Cloud sync requires Firebase configuration and an authenticated user.</span></div>
        <div style="margin-top:14px"><button class="secondary" data-view="settings">Configure backup & sync</button></div>
      </section>
    </div>
    <section class="panel" style="margin-top:16px"><h3>Recent students</h3><div class="panel-sub">Latest records saved on this device</div><div id="recentStudents"></div></section>`;
  $("dashPending").textContent=await queueCount();
  const last=await getMeta("lastSync"); $("lastSyncText").textContent=last?.value?new Date(last.value).toLocaleString():"Never";
  const recent=students.sort((a,b)=>(b.updatedAt||"").localeCompare(a.updatedAt||"")).slice(0,5);
  $("recentStudents").innerHTML=recent.length?tableHtml("students",recent,false):emptyState("No students yet","Use “Add student” to create your first record.");
}
async function renderCollection(name) {
  const rows=await getAll(name);
  const labels={students:"student",teachers:"teacher",classes:"class"};
  const searchPlaceholder=name==="classes"?"Search class or section…":"Search by name, ID, class or contact…";
  root.innerHTML=`${pageHeading(collectionLabels[name],`Manage your ${labels[name]} records stored on this device.`, `<button class="primary" data-add="${name}">＋ Add ${labels[name]}</button>`)}
    <section class="table-card"><div class="table-toolbar"><input class="search-box" id="tableSearch" placeholder="${searchPlaceholder}"><span class="small-muted">${rows.length} record(s)</span></div><div id="tableResult"></div></section>`;
  const draw=(filter="")=>{const q=filter.toLowerCase();const filtered=rows.filter(r=>Object.values(r).some(v=>String(v??"").toLowerCase().includes(q)));$("tableResult").innerHTML=tableHtml(name,filtered,true);};
  draw(); $("tableSearch").addEventListener("input",e=>draw(e.target.value));
}
function tableHtml(name,rows,actions=true) {
  if(!rows.length)return emptyState("No records found","Add a record or change your search.");
  let cols={students:[["name","Student"],["rollNo","Roll no."],["className","Class"],["guardian","Parent / guardian"],["phone","Contact"],["status","Status"]],teachers:[["name","Teacher"],["employeeId","Employee ID"],["subject","Subject"],["phone","Contact"],["status","Status"]],classes:[["name","Class"],["section","Section"],["teacher","Class teacher"],["room","Room"],["academicYear","Academic year"]]}[name]||[];
  const head=cols.map(c=>`<th>${c[1]}</th>`).join("")+(actions?"<th>Actions</th>":"");
  const body=rows.map(r=>`<tr>${cols.map(([key,label],i)=>`<td>${i===0?`<div class="person"><div class="avatar">${escapeHtml(initials(r[key]))}</div><b>${escapeHtml(r[key]||"—")}</b></div>`:key==="status"?`<span class="badge ${r[key]==="Active"?"green":"red"}">${escapeHtml(r[key]||"—")}</span>`:escapeHtml(r[key]||"—")}</td>`).join("")}${actions?`<td><div class="actions"><button class="mini-btn" data-edit="${name}" data-id="${escapeHtml(r.id)}">Edit</button><button class="mini-btn delete" data-delete="${name}" data-id="${escapeHtml(r.id)}">Delete</button></div></td>`:""}</tr>`).join("");
  return `<div class="table-wrap"><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
}
async function renderAttendance() {
  const rows=(await getAll("attendance")).sort((a,b)=>(b.date||"").localeCompare(a.date||""));
  root.innerHTML=`${pageHeading("Attendance","Record and review daily student attendance.",'<button class="primary" data-add="attendance">＋ Mark attendance</button>')}
  <section class="table-card"><div class="table-toolbar"><input class="search-box" id="tableSearch" placeholder="Search date, student, class…"><span class="small-muted">${rows.length} entries</span></div><div id="tableResult"></div></section>`;
  const draw=q=>{const filtered=rows.filter(r=>Object.values(r).some(v=>String(v??"").toLowerCase().includes((q||"").toLowerCase())));$("tableResult").innerHTML=filtered.length?`<div class="table-wrap"><table><thead><tr><th>Date</th><th>Student</th><th>Roll no.</th><th>Class</th><th>Status</th><th>Remarks</th><th>Actions</th></tr></thead><tbody>${filtered.map(r=>`<tr><td>${escapeHtml(r.date)}</td><td>${escapeHtml(r.studentName)}</td><td>${escapeHtml(r.rollNo||"—")}</td><td>${escapeHtml(r.className)}</td><td><span class="badge ${r.status==="Present"?"green":r.status==="Absent"?"red":""}">${escapeHtml(r.status)}</span></td><td>${escapeHtml(r.remarks||"—")}</td><td><div class="actions"><button class="mini-btn" data-edit="attendance" data-id="${escapeHtml(r.id)}">Edit</button><button class="mini-btn delete" data-delete="attendance" data-id="${escapeHtml(r.id)}">Delete</button></div></td></tr>`).join("")}</tbody></table></div>`:emptyState("No attendance entries","Mark attendance to get started.");};
  draw("");$("tableSearch").addEventListener("input",e=>draw(e.target.value));
}
async function renderExams() {
  const rows=await getAll("exams");
  root.innerHTML=`${pageHeading("Examinations & results","Enter marks and print a simple result list.",'<button class="primary" data-add="exams">＋ Add result</button>')}<section class="table-card"><div class="table-toolbar"><input class="search-box" id="tableSearch" placeholder="Search student, exam or subject…"><button class="secondary" id="printCurrent">Print report</button></div><div id="tableResult"></div></section>`;
  const draw=q=>{const f=rows.filter(r=>Object.values(r).some(v=>String(v??"").toLowerCase().includes((q||"").toLowerCase())));$("tableResult").innerHTML=f.length?`<div class="table-wrap"><table><thead><tr><th>Student</th><th>Roll no.</th><th>Class</th><th>Exam</th><th>Subject</th><th>Marks</th><th>Percentage</th><th>Actions</th></tr></thead><tbody>${f.map(r=>{let pct=Number(r.totalMarks)?Math.round(Number(r.obtainedMarks)/Number(r.totalMarks)*100):0;return `<tr><td>${escapeHtml(r.studentName)}</td><td>${escapeHtml(r.rollNo||"—")}</td><td>${escapeHtml(r.className)}</td><td>${escapeHtml(r.examName)}</td><td>${escapeHtml(r.subject)}</td><td>${escapeHtml(r.obtainedMarks)} / ${escapeHtml(r.totalMarks)}</td><td>${pct}%</td><td><div class="actions"><button class="mini-btn" data-edit="exams" data-id="${escapeHtml(r.id)}">Edit</button><button class="mini-btn delete" data-delete="exams" data-id="${escapeHtml(r.id)}">Delete</button></div></td></tr>`}).join("")}</tbody></table></div>`:emptyState("No results yet","Add exam marks for students.");};
  draw("");$("tableSearch").addEventListener("input",e=>draw(e.target.value));$("printCurrent").onclick=()=>window.print();
}
async function renderFees() {
  const rows=await getAll("fees");const paid=rows.reduce((s,r)=>s+Number(r.amountPaid||0),0);const due=rows.reduce((s,r)=>s+Math.max(0,Number(r.amountDue||0)-Number(r.amountPaid||0)),0);
  root.innerHTML=`${pageHeading("Fees & payments","Track fee charges, payments and outstanding balances.",'<button class="primary" data-add="fees">＋ Record fee</button>')}<div class="grid stats-grid">${statCard("Collected",money(paid),"₨","#d9f5e9")}${statCard("Outstanding",money(due),"◷","#f7dce9")}</div><section class="table-card"><div class="table-toolbar"><input class="search-box" id="tableSearch" placeholder="Search student or fee month…"><button class="secondary" id="printCurrent">Print</button></div><div id="tableResult"></div></section>`;
  const draw=q=>{const f=rows.filter(r=>Object.values(r).some(v=>String(v??"").toLowerCase().includes((q||"").toLowerCase())));$("tableResult").innerHTML=f.length?`<div class="table-wrap"><table><thead><tr><th>Student</th><th>Roll no.</th><th>Class</th><th>Month</th><th>Due</th><th>Paid</th><th>Balance</th><th>Actions</th></tr></thead><tbody>${f.map(r=>`<tr><td>${escapeHtml(r.studentName)}</td><td>${escapeHtml(r.rollNo||"—")}</td><td>${escapeHtml(r.className||"—")}</td><td>${escapeHtml(r.month)}</td><td>${money(r.amountDue)}</td><td>${money(r.amountPaid)}</td><td><b>${money(Math.max(0,Number(r.amountDue||0)-Number(r.amountPaid||0)))}</b></td><td><div class="actions"><button class="mini-btn" data-edit="fees" data-id="${escapeHtml(r.id)}">Edit</button><button class="mini-btn delete" data-delete="fees" data-id="${escapeHtml(r.id)}">Delete</button></div></td></tr>`).join("")}</tbody></table></div>`:emptyState("No fee records","Record a fee payment to begin.");};draw("");$("tableSearch").addEventListener("input",e=>draw(e.target.value));$("printCurrent").onclick=()=>window.print();
}
async function renderNotices() {
  const rows=(await getAll("notices")).sort((a,b)=>(b.publishDate||"").localeCompare(a.publishDate||""));
  root.innerHTML=`${pageHeading("Notices & announcements","Create school announcements. This starter stores notices locally.",'<button class="primary" data-add="notices">＋ New notice</button>')}<div class="notice-list">${rows.length?rows.map(r=>`<article class="notice-item"><div style="display:flex;justify-content:space-between;gap:10px"><strong>${escapeHtml(r.title)}</strong><div class="actions"><button class="mini-btn" data-edit="notices" data-id="${escapeHtml(r.id)}">Edit</button><button class="mini-btn delete" data-delete="notices" data-id="${escapeHtml(r.id)}">Delete</button></div></div><small>${escapeHtml(r.publishDate)} • ${escapeHtml(r.audience)}</small><p>${escapeHtml(r.body)}</p></article>`).join(""):emptyState("No notices published","Create a notice for students, parents or staff.")}</div>`;
}
async function renderSettings() {
  const pending=await queueCount(), last=await getMeta("lastSync");
  const configured=isFirebaseConfigured();
  root.innerHTML=`${pageHeading("Settings & Backup","Configure cloud sync and protect the school's records.")}
  <div class="grid settings-grid">
    <section class="panel settings-card"><h3>School profile</h3><p>Set the school name shown in the interface.</p><label class="field">School name<input id="schoolNameInput" value="${escapeHtml(await (async()=>{const x=await getMeta("schoolName");return x?.value||"My School"})())}"></label><button class="primary" id="saveSchoolName">Save school name</button></section>
    <section class="panel settings-card"><h3>Firebase cloud sync</h3><p>Status: <span class="badge ${configured?"green":"red"}">${configured?"Configuration found":"Not configured"}</span></p><p>Add your Firebase Web App configuration in <code>js/firebase.js</code>, enable Email/Password Authentication and create Firestore. Then sign in with a user created in Firebase Authentication.</p><p>Pending changes: <b>${pending}</b><br>Last successful sync: <b>${last?.value?new Date(last.value).toLocaleString():"Never"}</b></p><div class="setting-actions"><button class="secondary" id="testSync">Try sync now</button><button class="secondary" id="downloadGuide">Download setup guide</button></div></section>
    <section class="panel settings-card"><h3>Local backup</h3><p>Export all records saved in this browser to a JSON backup file. Keep it somewhere safe. Importing a backup replaces the local stores in this browser.</p><div class="setting-actions"><button class="primary" id="exportBackup">Export backup</button><label class="secondary" style="display:inline-flex;align-items:center;gap:8px">Import backup<input id="importBackupFile" type="file" accept="application/json,.json" hidden></label></div></section>
    <section class="panel settings-card"><h3>Local storage status</h3><p>Records are saved in this browser's IndexedDB. They are tied to this browser profile and device. Clearing browser data or uninstalling a WebView app may remove them.</p><div class="sync-info">Internet: <b>${navigator.onLine?"Available":"Unavailable"}</b><br>Pending sync: <b>${pending}</b><br>Current mode: <b>${isDemoMode()?"Local demo":"Firebase / local mode"}</b></div><p><b>Important:</b> Demo mode does not upload data to Firebase.</p></section>
  </div>`;
  $("saveSchoolName").onclick=async()=>{const name=$("schoolNameInput").value.trim()||"My School";await setMeta("schoolName",name);$("schoolNameSide").textContent=name;toast("School name saved on this device.");};
  $("testSync").onclick=async()=>{const result=await syncPending();toast(result.message,!result.ok);await updateSyncBadge();renderSettings();};
  $("exportBackup").onclick=async()=>{const data=await exportAll();downloadBlob(JSON.stringify(data,null,2),"school-management-backup-"+today()+".json","application/json");toast("Backup exported.");};
  $("importBackupFile").onchange=async e=>{const file=e.target.files?.[0];if(!file)return;try{const data=JSON.parse(await file.text());if(!confirm("Importing will replace local records in this browser. Continue?"))return;await importAll(data);toast("Backup imported.");renderView();updateSyncBadge();}catch(err){toast("Import failed: "+err.message,true);}e.target.value="";};
  $("downloadGuide").onclick=()=>downloadBlob(SETUP_GUIDE,"Firebase-Setup-Guide.txt","text/plain");
}
const SETUP_GUIDE=`SCHOOL MANAGEMENT SYSTEM — FIREBASE SETUP\n\n1. Create a Firebase project: https://console.firebase.google.com/\n2. Add a Web App in Project settings and copy its config.\n3. Paste the config values into js/firebase.js.\n4. In Authentication > Sign-in method, enable Email/Password.\n5. In Authentication > Users, create the first admin user.\n6. Create a Cloud Firestore database.\n7. Host this website over HTTPS (Firebase Hosting is recommended). ES modules and service workers do not work reliably from file:// URLs.\n8. IMPORTANT: configure Firestore Security Rules before using real school data. Never use open test rules in production.\n9. This starter writes to schools/{projectId}/{collection}/{recordId}. This path is only a starter structure. Before real deployment, change it to a unique school ID and enforce role/school membership in rules.\n10. Local demo mode is not authenticated and never syncs to the cloud.\n\nOFFLINE NOTES\n- IndexedDB saves records locally first.\n- A queue stores changes waiting for cloud sync.\n- Press Sync now or reopen the app after the internet returns.\n- Ordinary browser pages cannot guarantee continuous background sync while closed. Android WebView may need native WorkManager integration for stronger guarantees.\n- Photos and files are not yet uploaded; this starter stores text fields only.\n- This is a starter project, not a security-audited production deployment.\n`;
function downloadBlob(content,name,type){const blob=new Blob([content],{type});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}

function openRecordDialog(collection, record=null) {
  currentCollection=collection;currentEditId=record?.id||null;
  $("dialogTitle").textContent=(record?"Edit ":"Add ")+(collectionLabels[collection]||collection);
  const fields=schema[collection]||[];
  $("dialogFields").innerHTML=fields.map(([key,label,type,required,options])=>{
    const value=record?.[key]??(key==="date"||key==="publishDate"?today():key==="month"?today().slice(0,7):key==="status"&&collection!=="attendance"?"Active":key==="amountPaid"||key==="amountDue"||key==="totalMarks"||key==="obtainedMarks"?"0":"");
    const req=required?"required":"";
    let input="";
    if(type==="select")input=`<select name="${key}" ${req}>${options.map(o=>`<option ${String(value)===o?"selected":""}>${o}</option>`).join("")}</select>`;
    else if(type==="textarea")input=`<textarea name="${key}" rows="3" ${req}>${escapeHtml(value)}</textarea>`;
    else input=`<input name="${key}" type="${type}" value="${escapeHtml(value)}" ${req} ${type==="number"?'min="0" step="any"':""}>`;
    return `<label class="field ${type==="textarea"?"full-span":""}">${label}${input}</label>`;
  }).join("");
  $("recordDialog").showModal();
}
async function saveRecord(event) {
  event.preventDefault();
  const form=new FormData($("recordForm"));const record={id:currentEditId||uid()};
  for(const [key,value] of form.entries())record[key]=String(value).trim();
  record.updatedAt=new Date().toISOString();
  if(currentCollection==="exams" && Number(record.obtainedMarks)>Number(record.totalMarks)){toast("Obtained marks cannot exceed total marks.",true);return;}
  if(currentCollection==="fees" && Number(record.amountPaid)>Number(record.amountDue)){toast("Amount paid cannot exceed amount due in this record.",true);return;}
  try {
    await put(currentCollection,record);
    await (await import("./sync.js")).queueChange(currentCollection,record,"upsert");
    $("recordDialog").close();toast(`${collectionLabels[currentCollection]||currentCollection} saved on this device.`);
    await renderView();await updateSyncBadge();
    if(navigator.onLine&&!isDemoMode()) {
      const result=await syncPending();if(result.ok)toast(result.message);
      await updateSyncBadge();
    }
  } catch(e){toast("Save failed: "+e.message,true);}
}
async function deleteRecord(collection,id) {
  const record=await getOne(collection,id);if(!record)return;
  if(!confirm(`Delete this ${collectionLabels[collection]?.toLowerCase()||"record"}?`))return;
  await remove(collection,id);
  const { enqueue }=await import("./database.js");
  await enqueue({id:`${collection}:${id}`,collection,recordId:id,operation:"delete",record:{id},updatedAt:new Date().toISOString(),queuedAt:new Date().toISOString()});
  toast("Record deleted locally; cloud deletion will sync when available.");
  await renderView();await updateSyncBadge();
}
document.addEventListener("click",async e=>{
  const add=e.target.closest("[data-add]");if(add){openRecordDialog(add.dataset.add);return;}
  const edit=e.target.closest("[data-edit]");if(edit){openRecordDialog(edit.dataset.edit,await getOne(edit.dataset.edit,edit.dataset.id));return;}
  const del=e.target.closest("[data-delete]");if(del){await deleteRecord(del.dataset.delete,del.dataset.id);return;}
  const view=e.target.closest("[data-view]");if(view){navTo(view.dataset.view);return;}
});
$("recordForm").addEventListener("submit",saveRecord);
$("closeDialog").onclick=()=>$("recordDialog").close();$("cancelDialog").onclick=()=>$("recordDialog").close();
$("mainNav").addEventListener("click",e=>{const b=e.target.closest("[data-view]");if(b)navTo(b.dataset.view);});
$("mobileMenu").onclick=()=>document.querySelector(".sidebar").classList.toggle("open");
$("syncNow").onclick=async()=>{const r=await syncPending();toast(r.message,!r.ok);await updateSyncBadge();if(currentView==="dashboard"||currentView==="settings")renderView();};
$("logoutBtn").onclick=async()=>{await signOut();showLogin();};
$("demoLogin").onclick=()=>{setDemoMode(true);showApp();toast("Local demo opened. Data is saved only in this browser.");};
$("loginForm").addEventListener("submit",async e=>{
  e.preventDefault();$("loginMessage").textContent="Signing in…";
  try {await signIn($("loginEmail").value.trim(),$("loginPassword").value);showApp();toast("Signed in successfully.");}
  catch(err){$("loginMessage").textContent=err.message||"Sign-in failed. Check Firebase configuration and credentials.";}
});
window.addEventListener("online",()=>{updateConnection();toast("Internet detected. Tap Sync now or save a record to sync pending changes.");updateSyncBadge();});
window.addEventListener("offline",()=>{updateConnection();toast("You are offline. New records will remain saved locally.");});
window.addEventListener("focus",async()=>{updateConnection();await updateSyncBadge();if(navigator.onLine&&!isDemoMode()&&currentUser())await syncPending();});
(async()=>{
  dateLabel();updateConnection();
  const name=await getMeta("schoolName");if(name?.value)$("schoolNameSide").textContent=name.value;
  await initializeFirebase();
  if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(console.warn);
  // Demo mode is intentionally explicit; real Firebase sign-in is separate.
})();
