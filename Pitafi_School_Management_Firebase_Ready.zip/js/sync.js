import { firebaseConfig, firebaseConfigured } from "./firebase.js";
import { getAll, put, remove, queueCount, setMeta } from "./database.js";

let app = null, auth = null, firestore = null;
let sdkReady = false;
let demoMode = false;

export function isFirebaseConfigured() { return firebaseConfigured; }
export function isDemoMode() { return demoMode; }
export function setDemoMode(value) { demoMode = Boolean(value); }
export function isSdkReady() { return sdkReady; }

export async function initializeFirebase() {
  if (!firebaseConfigured) return false;
  try {
    const appSdk = await import("https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js");
    const authSdk = await import("https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js");
    const fsSdk = await import("https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js");
    app = appSdk.initializeApp(firebaseConfig);
    auth = authSdk.getAuth(app);
    firestore = fsSdk.getFirestore(app);
    sdkReady = true;
    return true;
  } catch (e) {
    console.error("Firebase initialization failed", e);
    return false;
  }
}
export async function signIn(email, password) {
  if (!sdkReady) throw new Error("Firebase is not configured. Use local demo or configure js/firebase.js.");
  const { signInWithEmailAndPassword } = await import("https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js");
  const credential = await signInWithEmailAndPassword(auth, email, password);
  demoMode = false;
  return credential.user;
}
export async function signOut() {
  if (auth && !demoMode) {
    const { signOut: firebaseSignOut } = await import("https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js");
    await firebaseSignOut(auth);
  }
  demoMode = false;
}
export function currentUser() { return auth?.currentUser || null; }

// Queue items are idempotent: each record has a stable ID and a monotonically updated local timestamp.
export async function queueChange(collection, record, operation = "upsert") {
  const { enqueue } = await import("./database.js");
  const item = {
    id: `${collection}:${record.id}`,
    collection,
    recordId: record.id,
    operation,
    record: { ...record },
    updatedAt: record.updatedAt || new Date().toISOString(),
    queuedAt: new Date().toISOString()
  };
  await enqueue(item);
}

export async function syncPending() {
  if (!navigator.onLine) return { ok: false, message: "Offline — changes remain saved on this device." };
  if (!firebaseConfigured || !sdkReady || !firestore || demoMode || !currentUser()) {
    return { ok: false, message: "Local data is saved. Configure Firebase and sign in to cloud-sync it." };
  }
  const items = await getAll("syncQueue");
  if (!items.length) {
    await setMeta("lastSync", new Date().toISOString());
    return { ok: true, count: 0, message: "Everything is synced." };
  }
  const { doc, setDoc, deleteDoc, serverTimestamp } = await import("https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js");
  let synced = 0;
  for (const item of items) {
    try {
      const ref = doc(firestore, "schools", firebaseConfig.projectId, item.collection, item.recordId);
      // Security Rules must restrict access to the user's school. This starter uses a school-level path.
      if (item.operation === "delete") {
        await deleteDoc(ref);
      } else {
        await setDoc(ref, {
          ...item.record,
          _sync: { updatedAt: item.updatedAt, updatedBy: currentUser().uid, serverUpdatedAt: serverTimestamp() }
        }, { merge: true });
      }
      await remove("syncQueue", item.id);
      synced++;
    } catch (error) {
      console.error("Sync item failed", item, error);
      // Leave it queued for the next attempt.
    }
  }
  const remaining = await queueCount();
  if (remaining === 0) await setMeta("lastSync", new Date().toISOString());
  return { ok: remaining === 0, count: synced, remaining, message: remaining ? `${synced} synced; ${remaining} still pending. Check Firebase rules/network.` : `${synced} record(s) synced successfully.` };
}
